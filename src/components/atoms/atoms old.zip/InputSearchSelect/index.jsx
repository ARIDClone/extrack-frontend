import React, { useState, useEffect } from 'react'
import {
  Button,
  FormControl,
  FormErrorMessage,
  FormLabel,
  Stack,
  VisuallyHiddenInput,
} from '@chakra-ui/react'
import { Select as SearchSelect } from 'chakra-react-select'

const InputSearchSelect = ({
  name,
  label,
  option = [],
  optionValue = 'id',
  optionLabel,
  isReadOnly = false,
  isRequired = true,
  isDisabled = false,
  errors,
  register,
  watch,
  setValue,
  getValues,
  defValue,
}) => {
  const [selectedValue, setSelectedValue] = useState([])

  useEffect(() => {
    if (option.length > 0 && getValues(name) !== null) {
      const findValue = option.find(opt => opt[optionValue] == getValues(name))
      if (findValue) {
        setSelectedValue({
          label: findValue[optionLabel],
          value: findValue[optionValue],
        })
      }
    } else if (getValues(name) === '') {
      setSelectedValue([])
    }
  }, [watch(name)])

  return (
    <FormControl
      isInvalid={errors[name]}
      display={'inline-flex'}
      pt={4}
      isRequired={isRequired}
    >
      <FormLabel htmlFor={name} mt={2} minWidth={'200px'}>
        {label}
      </FormLabel>
      <VisuallyHiddenInput
        id={name}
        {...register(name, {
          required: isRequired ? 'Required' : undefined,
        })}
      />

      <Stack direction={'column'} width={'100%'}>
        <SearchSelect
          options={
            option &&
            option.map(opt => ({
              value: opt[optionValue],
              label: opt[optionLabel],
            }))
          }
          onChange={e => {
            setSelectedValue(e)
            setValue(name, e.value)
          }}
          value={selectedValue}
          isReadOnly={isReadOnly}
          menuPortalTarget={document.body}
          styles={{
            menuPortal: provided => ({ ...provided, zIndex: 10 }),
          }}
          // variant={isReadOnly ? 'gray.300' : ''}
          chakraStyles={{
            container: (provided, state) => ({
              ...provided,
              borderRadius: '10',
              background: isReadOnly ? 'gray.300' : '',
            }),
          }}
        />

        {/* <Select
					id={name}
					placeholder={label}
					isReadOnly={isReadOnly}
					style={{ pointerEvents: isReadOnly ? 'none' : '' }}
					isDisabled={isDisabled}
					background={isReadOnly ? 'gray.300' : ''}
					{...register(name, {
						required: isRequired ? 'Required' : undefined,
					})}
				>
					{option && option.map((opt, idx) => (
						<option key={idx} value={opt[optionValue]} disabled={isReadOnly}>{opt[optionLabel]}</option>
					))}
				</Select> */}

        <FormErrorMessage>
          {errors[name] && errors[name].message}
        </FormErrorMessage>
      </Stack>
    </FormControl>
  )
}

export default InputSearchSelect
