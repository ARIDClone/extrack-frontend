import { FormControl, FormErrorMessage, Input } from "@chakra-ui/react";
import { Controller } from "react-hook-form";

const InputDateTime = ({ errors, control, name, isRequired = true, max, min, sx }) => (
  <FormControl isInvalid={errors[name]} {...sx}>
    <Controller
      control={control}
      name={name}
      rules={{ required: isRequired ? "Required" : undefined }}
      render={({ field: { onChange, onBlur, value = "", ref } }) => (
        <Input
          colorScheme="primary"
          type={'datetime-local'}
          placeholder={name}
          onChange={onChange}
          onBlur={onBlur}
          max={max}
          min={min}
          value={value}
        />
      )}
    />
    <FormErrorMessage>{errors[name] && errors[name].message}</FormErrorMessage>
  </FormControl>
);

export default InputDateTime;
