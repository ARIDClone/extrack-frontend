import { Checkbox, FormControl, FormErrorMessage, HStack, Input, Text } from "@chakra-ui/react";
import { Controller } from "react-hook-form";

const InputCheckbox = ({ errors, control, name, isRequired = true, placeholder, sx }) => (
  <FormControl isInvalid={errors[name]} {...sx}>
    <Controller
      control={control}
      name={name}
      rules={{ required: isRequired ? "Required" : undefined }}
      render={({ field: { onChange, onBlur, value = "", ref } }) => (
        <HStack className="asd">
          <Checkbox
            // placeholder={placeholder}
            colorScheme="primary"
            onChange={onChange}
            onBlur={onBlur}
            value={value}
            isChecked={value}
          />
          <Text>{placeholder}</Text>
        </HStack>
      )}
    />
    <FormErrorMessage>{errors[name] && errors[name].message}</FormErrorMessage>
  </FormControl>
);

export default InputCheckbox;
