import {
  FormControl,
  FormErrorMessage,
  Radio,
  RadioGroup,
  Stack,
} from "@chakra-ui/react";
import { Controller } from "react-hook-form";

const InputRadio = ({
  errors,
  control,
  name,
  isRequired = true,
  option = [],
  direction,
  sx,
}) => (
  <FormControl isInvalid={errors[name]} {...sx}>
    <Controller
      control={control}
      name={name}
      rules={{
        // required: isRequired ? "Required" : undefined,
        validate: isRequired ? (x) => x != null : undefined,
      }}
      render={({ field }) => (
        <RadioGroup
          type
          onBlur={field.onBlur}
          value={field.value}
          {...field}
          // onChange={(e) => field.onChange(e)}
          onChange={(e) => {
            if (e == true || e == "true") field.onChange(true);
            else if (e == false || e == "false") field.onChange(false);
            else field.onChange(e);
          }}
          colorScheme="primary"
        >
          <Stack direction={direction}>
            {option.map((opt, idx) => (
              <Radio
                key={idx}
                value={opt.value}
                checked={(field.value = opt.value)}
              >
                {opt.name}
              </Radio>
            ))}
          </Stack>
        </RadioGroup>
      )}
    />
    <FormErrorMessage>{errors[name] && errors[name].message}</FormErrorMessage>
  </FormControl>
);

export default InputRadio;
