import { Box, Text } from "@chakra-ui/react";

const Label = ({ children, isRequired, ...rest }) => (
  <Text
    fontWeight={"semibold"}
    color={"gray.500"}
    minW={200}
    alignSelf={'start'}
    pt={2}
    {...rest}
  >
    {children}
  </Text>
);

export default Label;
