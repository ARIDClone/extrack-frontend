import {
  FormControl,
  FormErrorMessage,
  FormLabel,
  Input,
  Stack,
} from '@chakra-ui/react'
import React from 'react'

const InputDate = ({
  name,
  label,
  min,
  isReadOnly = false,
  isRequired = true,
  isDisabled = false,
  errors,
  register,
}) => {
  return (
    <FormControl
      isInvalid={errors[name]}
      display={'inline-flex'}
      pt={4}
      isRequired={isRequired}
    >
      <FormLabel htmlFor={name} mt={2} minWidth={'200px'}>
        {label}
      </FormLabel>

      <Stack direction={'column'} width={'100%'}>
        <Input
          id={name}
          placeholder={label}
          isReadOnly={isReadOnly}
          isDisabled={isDisabled}
          background={isReadOnly ? 'gray.300' : ''}
          type={'date'}
          min={min}
          {...register(name, {
            required: isRequired ? 'Required' : undefined,
          })}
        />

        <FormErrorMessage>
          {errors[name] && errors[name].message}
        </FormErrorMessage>
      </Stack>
    </FormControl>
  )
}

export default InputDate
