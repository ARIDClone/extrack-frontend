import {
  FormControl,
  FormErrorMessage,
  FormLabel,
  Input,
  Stack,
} from '@chakra-ui/react'
import React from 'react'

const InputText = ({
  name,
  label,
  isReadOnly = false,
  isRequired = true,
  isDisabled = false,
  errors,
  register,
  value,
}) => {
  return (
    <FormControl
      isInvalid={errors[name]}
      display={'inline-flex'}
      pt={4}
      isRequired={isRequired}
    >
      <FormLabel htmlFor={name} mt={2} minWidth={'200px'}>
        {label}
      </FormLabel>

      <Stack direction={'column'} width={'100%'}>
        <Input
          id={name}
          placeholder={label}
          isReadOnly={isReadOnly}
          isDisabled={isDisabled}
          value={value}
          background={isReadOnly ? 'gray.300' : ''}
          {...register(name, {
            required: isRequired ? 'Required' : undefined,
            // minLength: { value: 4, message: 'Minimum length should be 4' },
          })}
        />

        <FormErrorMessage>
          {errors[name] && errors[name].message}
        </FormErrorMessage>
      </Stack>
    </FormControl>
  )
}

export default InputText
