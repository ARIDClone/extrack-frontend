/* eslint-disable react/no-children-prop */
import { FormControl, FormErrorMessage, Input, InputGroup, InputRightAddon, Select } from "@chakra-ui/react";
import { Controller } from "react-hook-form";

const InputSelect = ({
  errors,
  control,
  name,
  isRequired = true,
  option,
  optionValue = "id",
  optionLabel = "name",
  placeholder = name,
  rightText = '',
  sx,
}) => (
  <FormControl isInvalid={errors[name]} {...sx}>
    <Controller
      control={control}
      name={name}
      rules={{ required: isRequired ? "Required" : undefined }}
      render={({ field: { onChange, onBlur, value = "", ref } }) => (
        <InputGroup>
          <Select
            placeholder={placeholder}
            onChange={onChange}
            onBlur={onBlur}
            value={value}
          >
            {/* <option value={''}></option> */}
            {option.map((opt, idx) => (
              <option key={idx} value={opt[optionValue]}>
                {opt[optionLabel]}
              </option>
            ))}
          </Select>
          {rightText && <InputRightAddon fontSize={'sm'} children={rightText} />}
        </InputGroup>
      )}
    />
    <FormErrorMessage>{errors[name] && errors[name].message}</FormErrorMessage>
  </FormControl>
);

export default InputSelect;
