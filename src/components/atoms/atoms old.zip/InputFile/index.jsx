import {
  FormControl,
  FormErrorMessage,
  FormLabel,
  Input,
  InputGroup,
  InputLeftElement,
  Stack,
  Icon,
  VisuallyHiddenInput,
  InputRightElement,
  InputRightAddon,
  Text,
  Box,
} from '@chakra-ui/react'
import { FiDelete, FiFile, FiTrash } from 'react-icons/fi'
import React, { useEffect, useRef, useState } from 'react'

const InputFile = ({
  name,
  label,
  acceptedFileTypes,
  isReadOnly = false,
  isRequired = true,
  isDisabled = false,
  errors,
  register,
  setValue,
  watch,
}) => {
  const inputRef = useRef()
  const [fileName, setFileName] = useState('')

  const handleOnChange = e => {
    const [file] = e.target.files

    if (file) {
      let reader = new FileReader()
      reader.readAsDataURL(file)
      reader.onloadend = () => {
        setFileName(file.name)
        setValue(name, {
          fileName: file.name,
          file: reader.result,
          rawFile: file,
        })
      }
    } else {
      setFileName('')
      setValue(name, null)
    }
  }

  useEffect(() => {
    if (watch(name)) {
      setFileName(watch(name)?.fileName)
    }
  }, [watch(name)])

  return (
    <FormControl
      isInvalid={errors[name]}
      display={'inline-flex'}
      pt={4}
      isRequired={isRequired}
    >
      <FormLabel htmlFor={name} mt={2} minWidth={'200px'}>
        {label}
      </FormLabel>

      <Stack direction={'column'} width={'100%'}>
        <VisuallyHiddenInput
          id={name}
          {...register(name, {
            required: isRequired ? 'Required' : undefined,
          })}
        />

        <InputGroup>
          <InputLeftElement
            pointerEvents='none'
            // eslint-disable-next-line react/no-children-prop
            children={<Icon as={FiFile} />}
          />
          <input
            type='file'
            accept={acceptedFileTypes}
            name={name}
            ref={inputRef}
            style={{ display: 'none' }}
            onChange={handleOnChange}
          ></input>
          <Input
            placeholder={label || 'Your file ...'}
            background={isReadOnly ? 'gray.300' : ''}
            onClick={() =>
              isReadOnly === false ? inputRef.current.click() : null
            }
            readOnly
            value={fileName}
          />
          <InputRightAddon
            // eslint-disable-next-line react/no-children-prop
            children={<Icon as={FiTrash} />}
            color={'red'}
            sx={{ cursor: isReadOnly === false ? 'pointer' : '' }}
            onClick={() => {
              if (!isReadOnly) {
                console.log('zxczxc')
                setFileName('')
                setValue(name, null)
              }
            }}
          />

          <Box className='attachment--info' marginLeft={5}>
            <Text fontSize={'xs'} textAlign={'left'}>
              Maximum file size: <span style={{ color: 'red' }}>5MB</span>
            </Text>
            <Text fontSize={'xs'} textAlign={'left'}>
              Valid extensions are{' '}
              <span style={{ color: 'red' }}>jpeg, jpg, png</span>
            </Text>
          </Box>
        </InputGroup>

        <FormErrorMessage>
          {errors[name] && errors[name].message}
        </FormErrorMessage>
      </Stack>
    </FormControl>
  )
}

export default InputFile
