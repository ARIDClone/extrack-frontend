import React from 'react'
import {
  FormControl,
  FormErrorMessage,
  FormLabel,
  Select,
  Stack,
  Textarea,
} from '@chakra-ui/react'

const InputTextArea = ({
  name,
  label,
  isReadOnly = false,
  isRequired = true,
  isDisabled = false,
  errors,
  register,
}) => {
  return (
    <FormControl
      isInvalid={errors[name]}
      display={'inline-flex'}
      pt={4}
      isRequired={isRequired}
    >
      <FormLabel htmlFor={name} mt={2} minWidth={'200px'}>
        {label}
      </FormLabel>

      <Stack direction={'column'} width={'100%'}>
        <Textarea
          id={name}
          placeholder={label}
          isReadOnly={isReadOnly}
          isDisabled={isDisabled}
          background={isReadOnly ? 'gray.300' : ''}
          {...register(name, {
            required: isRequired ? 'Required' : undefined,
          })}
        />

        <FormErrorMessage>
          {errors[name] && errors[name].message}
        </FormErrorMessage>
      </Stack>
    </FormControl>
  )
}

export default InputTextArea
