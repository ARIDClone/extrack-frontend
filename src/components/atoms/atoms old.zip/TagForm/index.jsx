import { FormControl, FormLabel, Input, Tag } from '@chakra-ui/react'
import React from 'react'

const TagForm = ({ name, label, isRequired = true, register, watch }) => {
  return (
    <FormControl display={'inline-flex'} pt={4}>
      <FormLabel htmlFor={name} mt={2} minWidth={'200px'}>
        {label}
      </FormLabel>

      <Input
        id={name}
        display={'none'}
        value={''}
        {...register(name, {
          required: isRequired ? 'Required' : undefined,
          // minLength: { value: 4, message: 'Minimum length should be 4' },
        })}
      />
      {watch(name) === 'waiting approval' ||
      watch(name) === 'Waiting Approval' ||
      watch(name) === 'WAITING APPROVAL' ? (
        <Tag
          variant='solid'
          colorScheme='yellow'
          minWidth={16}
          justifyContent={'center'}
        >
          Waiting Approval
        </Tag>
      ) : watch(name) === 'approved' ? (
        <Tag
          variant='solid'
          colorScheme='green'
          minWidth={16}
          justifyContent={'center'}
        >
          Approved
        </Tag>
      ) : watch(name) === 'rejected' ? (
        <Tag
          variant='solid'
          colorScheme='red'
          minWidth={16}
          justifyContent={'center'}
        >
          Rejected
        </Tag>
      ) : watch(name) === 'draft' ||
        watch(name) === 'Draft' ||
        watch(name) === 'DRAFT' ? (
        <Tag
          variant='solid'
          colorScheme='cyan'
          minWidth={16}
          justifyContent={'center'}
        >
          Draft
        </Tag>
      ) : (
        <Tag
          variant='solid'
          colorScheme='gray'
          minWidth={16}
          justifyContent={'center'}
        >
          -
        </Tag>
      )}
    </FormControl>
  )
}

export default TagForm
